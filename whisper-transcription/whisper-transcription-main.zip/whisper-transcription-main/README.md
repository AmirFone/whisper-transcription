# whisper-transcription
Quickly transcribe
